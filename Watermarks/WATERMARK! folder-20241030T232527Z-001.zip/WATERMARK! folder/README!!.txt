I used 1500x1300 Resolution for this comp if your edit comp res is different then
you can scale up all of these effects to fit in to remove blocky edges because of the
glow effect then also align the text correctly to fit the middle thanks:)